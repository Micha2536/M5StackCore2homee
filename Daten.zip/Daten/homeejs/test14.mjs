//test
import HomeeAPI from './homeeAPI.mjs';
import Node from './node.mjs';
import Attribute from './attribute.mjs';
           
import https from 'https';
import http from 'http';
import fs from 'fs';
 
const data = fs.readFileSync('/var/www/html/config.json', 'utf8');
const config = JSON.parse(data);
const hue_ip = config.ip;
let nodes = [];
let node_id = [];
let service = [];

const filePath = 'antwort.txt';

// Optionen für die HTTPS-Anfrage
const options = {
  method: 'GET',
  headers: {
    'hue-application-key': config.key
  },
  rejectUnauthorized: false
};

// Device abruf der HUE
function hue_lights() {
  const request = https.request('https://'+hue_ip+'/clip/v2/resource/light', options, (response) => {
    let data = '';
    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      const message = JSON.parse(data);
   // console.log(message);
	fs.writeFile(filePath, data, (err) => {
	  if (err) throw err;
  console.log('Die Antwort wurde erfolgreich in die Datei gespeichert!');    
});  
      message.data.forEach((message)=>{
	        let i = 100 + parseInt(message.id_v1.slice(8));
          let c =[];
	
          node_id.push({"id" :i,"id_v1":  message.id,"type":"light"}); 
	 if (message.on){c.push(new Attribute(i*10+1, i, 0, 0, 1, message.on.on === true ? 1:0,  message.on.on === true ? 1 : 0 , 0, '', 1, 1, 1, ''))} // on off
	 if (message.dimming){c.push(new Attribute(i*10+2, i, 0, 0, 100, message.dimming.brightness , message.dimming.brightness, 0, '%25', 0.01, 1, 2, ''))}
          if (message.color){c.push(new Attribute(i*10+3, i, 0, 0, 16777215, xytorgb(message.color.xy.x , message.color.xy.y ,255), xytorgb(message.color.xy.x , message.color.xy.y ,255), 0, '', 1, 1, 23, '7001020%3B16419669%3B12026363%3B16525995'))}
	        if (message.color_temperature && message.color_temperature.mirek_valid === true ){c.push(new Attribute(i*10+4, i, 0, message.color_temperature.mirek_schema.mirek_minimum, message.color_temperature.mirek_schema.mirek_maximum , message.color_temperature.mirek == null ? 0 : message.color_temperature.mirek , message.color_temperature.mirek == null ? 0 : message.color_temperature.mirek  , 0, 'ct', 1, 1, 42, ''))} 
	 if (message.alert.action_values[0] ==='breathe'){let c1 = new Attribute(i*10+5, i, 0, 0, 1, 0, 0 , 0, '', 1, 1, 177, ''); c1.name = "Identifikation"; c.push(c1)} // Alert
         if (message.effects){
		let d = 1;
		let f = 6;
		message.effects.effect_values.forEach((e)=>{
				console.log(e);
			if (e !='no_effect'){				
				let c1 = new Attribute(i*10+f, i, d, 0, 1, 0, 0 , 0, '', 1, 1, 177, e); 
				c1.name = e ;
				c.push(c1);
				d = d+1;
				f = f+1;
		}
	}
	)} // Alert


	 nodes.push(new Node(message.metadata.name, i, (c.length === 1 || c.length === 2) ? 16 : 1002, c));
         service.push({"id":message.owner.rid , "nodeid":i});
	console.log(service);
	       });
      });
  });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  request.end();
	myFunction();
}

function hue_rooms() {
  const request = https.request('https://'+hue_ip+'/clip/v2/resource/room', options, (response) => {
    let data = '';
    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      const message = JSON.parse(data);
  //  console.log(message);
    
        message.data.forEach((message)=>{
	        let i = 200 + parseInt(message.id_v1.slice(8));
          let c =[];
          node_id.push({"id" :i,"id_v1":  message.services[0].rid,"type":"grouped_light"});
           c.push(new Attribute(i*10+1, i, 0, 0, 1, 0, 0, 0, '', 1, 1, 1, '')); // on off
          c.push(new Attribute(i*10+2, i, 0, 0, 100, 0 , 0, 0, '%25', 0.01, 1, 2, ''));
          c.push(new Attribute(i*10+3, i, 0, 0, 16777215, 0, 0, 0, '', 1, 1, 23, '7001020%3B16419669%3B12026363%3B16525995'));
          c.push(new Attribute(i*10+4, i, 0, 150, 500 , 150, 150, 0, 'ct', 1, 1, 42, ''));
          nodes.push(new Node('Raum '+message.metadata.name, i,  1002, c));
     
//console.log(node_id);
	       });
      });
  });
  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  request.end();
}

function hue_zones() {
  const request = https.request('https://'+hue_ip+'/clip/v2/resource/zone', options, (response) => {
    let data = '';
    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      const message = JSON.parse(data);
    console.log(message);
    
        message.data.forEach((message)=>{
	        let i = 300 + parseInt(message.id_v1.slice(8));
          let c =[];
          node_id.push({"id" :i,"id_v1":  message.services[0].rid,"type":"grouped_light"});
          c.push(new Attribute(i*10+1, i, 0, 0, 1, 0, 0, 0, '', 1, 1, 1, '')); // on off
	  c.push(new Attribute(i*10+2, i, 0, 0, 100, 0 , 0, 0, '%25', 1, 1, 2, ''));
          c.push(new Attribute(i*10+3, i, 0, 0, 16777215, 0, 0, 0, '', 1, 1, 23, '7001020%3B16419669%3B12026363%3B16525995'));
	  c.push(new Attribute(i*10+4, i, 0, 150, 500 , 150, 150, 0, 'ct', 1, 1, 42, '')); 
          nodes.push(new Node('Zone '+message.metadata.name, i,  1002, c));
	       });
      });
  });
  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  request.end();
}

function hue_sensor() {
  const request = https.request('https://'+hue_ip+'/clip/v2/resource/device', options, (response) => {
    let data = '';
    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      const message = JSON.parse(data);
        message.data.forEach((message)=>{
          if (message.id_v1){
            if(message.id_v1.slice(1,8) === "sensors"){
              let i = 400 + parseInt(message.id_v1.slice(9));
              console.log(i);
              let c =[];
              let instance = 0;
              let d = 0;
                if (message.product_data.product_name === "Hue Smart button" || message.product_data.product_name === "Friends of Hue Switch"  || message.product_data.product_name === "Hue tap dial switch" || message.product_data.product_name === "Hue wall switch module" || message.product_data.product_name === "Hue dimmer switch"){
                  node_id.push({"id" :i,"id_v1":  message.services,"type":"device"});
                  message.services.forEach((a)=>{
                    d++;
		if ( a.rtype === "relative_rotary"){
                     // c.push(new Attribute(i*10+d, i, 0, 0, 100, 0, 0, 0, '%', 1, 1, 2, '')); //Rotary
		    let f = [];
		    f.push(new Attribute((i+100)*10+1, i+100 ,0,0,100,0,0,0,'%25', 0.01, 1,2, ''));
                      nodes.push(new Node(message.metadata.name, i+100 ,14 ,f));
		    service.push({"id":a.rid , "attribute_id":(i+100)*10+1});
                    }

                    if ( a.rtype === "device_power"){
                      c.push(new Attribute(i*10+d, i, 0, 0, 100, 0, 0, 0, '%', 0.01, 0, 8, '')); // Batterie 
                      service.push({"id":a.rid , "attribute_id":i*10+d});
                    }
                    else if ( a.rtype === "button"){
                      c.push(new Attribute(i*10+d, i, instance, 1, 2, 2, 2, 0, '', 1, 0, 40, '')); // taster 
                      service.push({"id":a.rid , "attribute_id":i*10+d});
                      instance++;
                    }
                    else if (a.rtype ==="zigbee_connectivity"){
                      service.push({"id":a.rid , "nodeid":i});
                    }

                  });
                  console.log(c);
                  nodes.push(new Node(message.metadata.name, i,  26 , c));
                }
		else if (message.product_data.product_name === "Hue motion sensor" || message.product_data.product_name === "Hue outdoor motion sensor"){
                  node_id.push({"id" :i,"id_v1":  message.services,"type":"device"});
                  message.services.forEach((a)=>{
                    d++;
                    if ( a.rtype === "device_power"){
                      c.push(new Attribute(i*10+d, i, 0, 0, 100, 0, 0, 0, '%', 0.01, 0, 8, '')); // Batterie
                      service.push({"id":a.rid , "attribute_id":i*10+d});
                    }
                    else if ( a.rtype === "motion"){
                      c.push(new Attribute(i*10+d, i, 0, 0, 1, 0, 0, 0, '', 1, 0, 25, '')); // motion
                      service.push({"id":a.rid , "attribute_id":i*10+d});
                    }
		                else if ( a.rtype === "temperature"){
                      c.push(new Attribute(i*10+d, i, 0, -50, 100, 0, 0, 0, '°C', 0.01, 0, 5, '')); // temperatur
                      service.push({"id":a.rid , "attribute_id":i*10+d});
                    }
		                else if ( a.rtype === "light_level"){
                      c.push(new Attribute(i*10+d, i, 0, 0, 100000, 0, 0, 0, 'Lux', 0.01, 0, 11, '')); // Lux
                      service.push({"id":a.rid , "attribute_id":i*10+d});
                    }
                    else if (a.rtype ==="zigbee_connectivity"){
                      service.push({"id":a.rid , "nodeid":i});
console.log(service);                   
 };

		
                  });
                  console.log(c);
                  nodes.push(new Node(message.metadata.name, i,  4015 , c));
                }
             } };
      });
      });
  });
  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  request.end();
}


function hue_power() {
  const request = https.request('https://'+hue_ip+'/clip/v2/resource/device_power', options, (response) => {
    let data = '';
    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      const message = JSON.parse(data);
	
      message.data.forEach((message)=>{
	if (service.find( d => d.id === message.id)){
        valueSet(service.find( d => d.id === message.id).attribute_id, message.power_state.battery_level)}
	       });
      });
  });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  request.end();

}

function hue_lux() {
  const request = https.request('https://'+hue_ip+'/clip/v2/resource/light_level', options, (response) => {
    let data = '';
    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      const message = JSON.parse(data);

      message.data.forEach((message)=>{
        if (service.find( d => d.id === message.id)){
        valueSet(service.find( d => d.id === message.id).attribute_id, message.light.light_level)}
               });
      });
  });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  request.end();

}


function hue_temp() {
  const request = https.request('https://'+hue_ip+'/clip/v2/resource/temperature', options, (response) => {
    let data = '';
    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      const message = JSON.parse(data);

      message.data.forEach((message)=>{
        if (service.find( d => d.id === message.id)){
        valueSet(service.find( d => d.id === message.id).attribute_id, message.temperature.temperature)}
               });
      });
  });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  request.end();

}

function hue_zigbee() {
  const request = https.request('https://'+hue_ip+'/clip/v2/resource/zigbee_connectivity', options, (response) => {
    let data = '';
    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      const message = JSON.parse(data);

      message.data.forEach((message)=>{
        if (service.find( d => d.id === message.owner.rid)){
		if (message.status ==='connected'){
                      const b = service.find( d => d.id === message.owner.rid);
                        const NodeState = nodes.find( a => a.id === b.nodeid);
                      NodeState.state = 1;
                    
                    }
                    else {
                      const b = service.find( d => d.id === message.owner.rid);

                        const NodeState = nodes.find( a => a.id === b.nodeid);
                      NodeState.state = 2;
                      
                    }
        
}
               });
      });
  });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  request.end();

}



// Stream zur hue  umbauen des eingangs noch auf switch case 
function stream_sse() {
  function handle_message(message) {
    const messages = JSON.parse(message);
    messages.forEach((msg) => {
          if (msg.data){ msg.data.forEach((msg) => {
		console.log(msg);
                  if(msg.type === 'light'){
                    if (msg.on){
		                  let c =  node_id.find(d => d.id_v1 === msg.id);
                      valueChanged((c.id*10)+1, msg.on.on == true ? 1 : 0)}
                    if (msg.dimming){
			                let c =  node_id.find(d => d.id_v1 === msg.id);	
                      valueChanged((c.id*10)+2, msg.dimming.brightness)}
                    if (msg.color_temperature && msg.color_temperature.mirek_valid === true){
	
			                let c =  node_id.find(d => d.id_v1 === msg.id);
                      valueChanged((c.id*10)+4, msg.color_temperature.mirek)}
                    }
                     if (msg.color){
			                let c =  node_id.find(d => d.id_v1 === msg.id);
                      console.log(xytorgb(msg.color.xy.x , msg.color.xy.y ,255));
                     valueChanged((c.id*10)+3, xytorgb(msg.color.xy.x , msg.color.xy.y ,255))
                    }

		else if(msg.type === "grouped_light" &&( msg.owner.rtype === 'room' || msg.owner.rtype === 'zone')){
                   if (msg.on){
                                   let c =  node_id.find(d => d.id_v1 === msg.id);
                      valueChanged((c.id*10)+1, msg.on.on == true ? 1 : 0)}
                    if (msg.dimming){
                                     let c =  node_id.find(d => d.id_v1 === msg.id);
                      valueChanged((c.id*10)+2, msg.dimming.brightness)}
                    if (msg.color_temperature){
                                         let c =  node_id.find(d => d.id_v1 === msg.id);
                    valueChanged((c.id*10)+4, msg.color_temperature.mirek)}
                    }
		else if (msg.type === "scene"){}

		 else if ( msg.type === 'relative_rotary'){
      if (msg.relative_rotary.last_event.rotation.direction === 'clock_wise'){
        const Attr = findAttribute(service.find( d => d.id === msg.id).attribute_id);
        let value = Attr.current_value + ( msg.relative_rotary.last_event.rotation.steps /3);
        if (value >= 100){value = 100};
        Attr.setCurrentValue(value);
        Attr.setTargetValue(value);
        api.send(JSON.stringify({'attribute': Attr}));
      }
      else if (msg.relative_rotary.last_event.rotation.direction === 'counter_clock_wise'){
        const Attr = findAttribute(service.find( d => d.id === msg.id).attribute_id);
        let value = Attr.current_value - ( msg.relative_rotary.last_event.rotation.steps /3);
        if (value <= 0){value = 0};
        Attr.setCurrentValue(value);
        Attr.setTargetValue(value);
        api.send(JSON.stringify({'attribute': Attr}));
      }
else {}
}









	                else if ( msg.type ==='button'){
			                if (msg.button.last_event ==='initial_press'){
			                  valueChanged(service.find( d => d.id === msg.id).attribute_id, 1)}
			                else  if (msg.button.last_event ==='short_release'){
                        valueChanged(service.find( d => d.id === msg.id).attribute_id, 2)}
		                }
		              else if ( msg.type ==='motion'){
                      if (msg.motion.motion ===true){
                        valueChanged(service.find( d => d.id === msg.id).attribute_id, 1)}
                      else  if (msg.motion.motion  === false){
                        valueChanged(service.find( d => d.id === msg.id).attribute_id, 0)}
                    }
		              else if ( msg.type ==='temperature'){
                        valueChanged(service.find( d => d.id === msg.id).attribute_id, parseFloat( msg.temperature.temperature))
                    }
		              else if ( msg.type ==='light_level'){
                        valueChanged(service.find( d => d.id === msg.id).attribute_id, parseFloat(msg.light.light_level))
                    }
                  else if ( msg.type ==='device_power'){
                        valueChanged(service.find( d => d.id === msg.id).attribute_id, parseFloat(msg.power_state.battery_level))
                    }
                  else if ( msg.type ==='zigbee_connectivity'){
                    if (msg.status ==='connected'){
                      const b = service.find( d => d.id === msg.owner.rid);
			const NodeState = nodes.find( a => a.id === b.nodeid);
                      NodeState.state = 1;
                     api.send(JSON.stringify({'node': NodeState}));
                    }
                    else {
                      const b = service.find( d => d.id === msg.owner.rid);
                    
                        const NodeState = nodes.find( a => a.id === b.nodeid);
                      NodeState.state = 2;
                      api.send(JSON.stringify({'node': NodeState}));
                    }
                  };


        });
      };
// Hier können Sie jedes Objekt weiterverarbeiten
});
};
 
const request = https.request('https://'+hue_ip+'/eventstream/clip/v2', options, (response) => {
  let buffer = '';
response.on('data', (chunk) => {
  buffer += chunk;

});

response.on('end', () => {
  const message = buffer.toString();
handle_message(message);
// Wenn die Verbindung zum SSE-Endpunkt beendet wird, die Funktion erneut aufrufen
stream_sse();
});
});

// Fehlerbehandlung
request.on('error', (error) => {
console.error('Fehler beim Verbinden mit dem SSE-Endpunkt:', error);

// Bei einem Fehler die Funktion erneut aufrufen
stream_sse();
});
request.end();
}

// Stream starte

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function myFunction() {
  // Hier kommt der Code, der sofort ausgeführt wird

  await delay(1000); // Hier wird eine Verzögerung von 1 Sekunde eingefügt

if (config.zone === true ){ hue_zones()}; 

 await delay(500);
 
 hue_sensor();// Hier kommt der Code, der nach der Verzögerung ausgeführt wird

await delay(500);

hue_power();

await delay(500);

hue_lux();

await delay(500);

hue_temp();

await delay(500);

hue_zigbee();

await delay(1000);

api.start();

await delay(1000);

stream_sse();


}

async function autoabruf() {
  // Hier kommt der Code, der sofort ausgeführt wird

  await delay(30000); // Hier wird eine Verzögerung von 1 Sekunde eingefügt

console.log("abfrage starten");
if(config.abfrageintervall === true){
const request = https.request('https://'+hue_ip+'/clip/v2/resource/light', options, (response) => {
    let data = '';
    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      const message = JSON.parse(data);

      message.data.forEach((msg)=>{
		console.log(msg);
                let i = 100 + parseInt(msg.id_v1.slice(8));
                   if (msg.on){
                                  
                      valueChanged((i*10)+1, msg.on.on == true ? 1 : 0)}
                    if (msg.dimming){
                                     
                      valueChanged((i*10)+2, msg.dimming.brightness)}
                    if (msg.color_temperature && msg.color_temperature.mirek_valid === true){
                                       
                    valueChanged((i*10)+4, msg.color_temperature.mirek)}


               });
      });
  });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  request.end();







 };
autoabruf();
};

autoabruf();


hue_rooms();
//hue_zones();
hue_lights();


// homee API setzen 
const api = new HomeeAPI('HUEBRIDGE');
// homee Nodes setzen
api.setNodes(nodes);

// auf eingänge von Homee reagieren 
api.on('put', (parsed) => {
console.log("eine Nachricht eingenagngen");
console.log(parsed);
let a = '';
if(parseInt(parsed.parameters.target_value) == 1){
a=true}
else {a=false}; 


console.log(findTypeOverAttributeId(parseInt(parsed.parameters.ids)));
if (findNodeTypeOverAttributeId(parseInt(parsed.parameters.ids)) == 14){
valueChanged(parseInt(parsed.parameters.ids),parseInt(parsed.parameters.target_value));
}

if (findTypeOverAttributeId(parseInt(parsed.parameters.ids)) == 1){ hue_req_on(a,findNodeIdOverAttributeId(parseInt(parsed.parameters.ids)))}
else if  (findTypeOverAttributeId(parseInt(parsed.parameters.ids)) == 2 && findNodeTypeOverAttributeId(parseInt(parsed.parameters.ids)) != 14 ){hue_req_dim(true,findNodeIdOverAttributeId(parseInt(parsed.parameters.ids)),parseInt(parsed.parameters.target_value))}
else if  (findTypeOverAttributeId(parseInt(parsed.parameters.ids)) == 42){hue_req_ct(true,findNodeIdOverAttributeId(parseInt(parsed.parameters.ids)),parseInt(parsed.parameters.target_value))}
else if  (findTypeOverAttributeId(parseInt(parsed.parameters.ids)) == 23){hue_req_color(true,findNodeIdOverAttributeId(parseInt(parsed.parameters.ids)),rgbtoxy(parseInt(parsed.parameters.target_value)));
valueChanged(parseInt(parsed.parameters.ids),parseInt(parsed.parameters.target_value));
}
else if  (findTypeOverAttributeId(parseInt(parsed.parameters.ids)) == 177 && findAttribute(parseInt(parsed.parameters.ids)).instance == 0 ){hue_req_ident(parseInt(parsed.parameters.ids),findNodeIdOverAttributeId(parseInt(parsed.parameters.ids)),parseInt(parsed.parameters.target_value))}

else if  (findTypeOverAttributeId(parseInt(parsed.parameters.ids)) == 177 && findAttribute(parseInt(parsed.parameters.ids)).instance != 0 ){
	hue_req_effect(parseInt(parsed.parameters.ids),findNodeIdOverAttributeId(parseInt(parsed.parameters.ids)),parseInt(parsed.parameters.target_value), findAttribute(parseInt(parsed.parameters.ids)).data)};
});






// Funktionen

// Hue funktionen Request an die Hue 

function hue_req_on(a,b){
  const options = {
    method: 'PUT',
    headers: {
      'hue-application-key': config.key
    },
    rejectUnauthorized: false
  };
  console.log(options);

  let c =  node_id.find(d => d.id === b);
	
  
 const request = https.request('https://' + hue_ip + '/clip/v2/resource/' + c.type + '/' + c.id_v1 , options, (response) => {
	let data = '';

  // Receive data stream
  response.on('data', (chunk) => {
    data += chunk;
  });

  // End of data stream
  response.on('end', () => {
    // Process response data
    console.log(data);
  });
    });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
const data = JSON.stringify({
	on:{
	on: a}
});
request.write(data);
  request.end();

 
}


function hue_req_ident(a,b,e){
  const options = {
    method: 'PUT',
    headers: {
      'hue-application-key': config.key
    },
    rejectUnauthorized: false
  };
  console.log(options);

  let c =  node_id.find(d => d.id === b);


 const request = https.request('https://' + hue_ip + '/clip/v2/resource/' + c.type + '/' + c.id_v1 , options, (response) => {
        let data = '';

  // Receive data stream
  response.on('data', (chunk) => {
    data += chunk;
  });

  // End of data stream
  response.on('end', () => {
    // Process response data
    console.log(data);
  });
    });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
const data = JSON.stringify({
        alert:{ action : "breathe"}
});
request.write(data);
  request.end();
valueChanged(a,0);
}


function hue_req_effect(a,b,e,f){
  const options = {
    method: 'PUT',
    headers: {
      'hue-application-key': config.key
    },
    rejectUnauthorized: false
  };
  console.log(options);

  let c =  node_id.find(d => d.id === b);

  
 const request = https.request('https://' + hue_ip + '/clip/v2/resource/' + c.type + '/' + c.id_v1 , options, (response) => {
        let data = '';

  // Receive data stream
  response.on('data', (chunk) => {
    data += chunk;
  });

  // End of data stream
  response.on('end', () => {
    // Process response data
    console.log(data);
  });
    });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
if ( e === 0 ){f='no_effect'};
const data = JSON.stringify({
on:{on:true},
        effects:{ effect : f}
});
request.write(data);
  request.end();
//valueChanged(a,0);
}







function hue_req_dim(a,b,e){
  const options = {
    method: 'PUT',
    headers: {
      'hue-application-key': config.key
    },
    rejectUnauthorized: false
  };
  console.log(options);

  let c =  node_id.find(d => d.id === b);
	
  
 const request = https.request('https://' + hue_ip + '/clip/v2/resource/' + c.type + '/' + c.id_v1 , options, (response) => {
	let data = '';

  // Receive data stream
  response.on('data', (chunk) => {
    data += chunk;
  });

  // End of data stream
  response.on('end', () => {
    // Process response data
    console.log(data);
  });
    });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  const data = JSON.stringify({
    'on': {'on':a},'dimming':{'brightness':e} });
request.write(data);
  request.end();
}




function hue_req_ct(a,b,e){
  const options = {
    method: 'PUT',
    headers: {
      'hue-application-key': config.key
    },
    rejectUnauthorized: false
  };
  console.log(options);

  let c =  node_id.find(d => d.id === b);


 const request = https.request('https://' + hue_ip + '/clip/v2/resource/' + c.type + '/' + c.id_v1 , options, (response) => {
        let data = '';

  // Receive data stream
  response.on('data', (chunk) => {
    data += chunk;
  });

  // End of data stream
  response.on('end', () => {
    // Process response data
    console.log(data);
  });
    });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  const data = JSON.stringify({
    'on': {'on':a},'color_temperature':{'mirek':e} });
request.write(data);
  request.end();
}



function hue_req_color(a,b,e){
   const options = {
    method: 'PUT',
    headers: {
      'hue-application-key': config.key
    },
    rejectUnauthorized: false
  };
  console.log(options);

  let c =  node_id.find(d => d.id === b);


 const request = https.request('https://' + hue_ip + '/clip/v2/resource/' + c.type + '/' + c.id_v1 , options, (response) => {
        let data = '';

  // Receive data stream
  response.on('data', (chunk) => {
    data += chunk;
  });

  // End of data stream
  response.on('end', () => {
    // Process response data
    console.log(data);
  });
    });

  request.on('error', (error) => {
    console.error(`HTTPS request error: ${error}`);
  });
  const data = JSON.stringify({
    'on': {'on':a},'color':{'xy':e} });
request.write(data);
  request.end();
}











  // Handle Messsage vom Hue Stream 


 





// homee Funktionen 
// zum auffinden der Werte in nodes 


function findAttribute(attributeID) { // Rückgabe kompletter Attribute Eintrag
  let found;
  nodes.find((node) => node.attributes.find((attr) => attr.id === attributeID && (found = attr)));
  return found;
}

function valueChanged(a, newValue) { // Änderung an homee senden über api.send()
  const Attr = findAttribute(a);
console.log(Attr);
if ( Attr.last_value != newValue){
 	console.log('changed to %o' , newValue);
	Attr.current_value = newValue;
	Attr.target_value = newValue;
// Attr.setCurrentValue(newValue);
//  Attr.setTargetValue(newValue);
	console.log(JSON.stringify({'attribute': Attr}));
	api.send(JSON.stringify({'attribute': Attr}));
	Attr.last_value = newValue;
}
console.log(Math.floor( (new Date()).getTime() / 1000));
// const NodeState = nodes.find( a => a.id === Attr.node_id);
//NodeState.state = 2;
// api.send({'node': NodeState}));
}

function valueSet(a, newValue) { // Änderung an homee senden über api.send()
  const Attr = findAttribute(a);
  Attr.setCurrentValue(newValue);
  Attr.setTargetValue(newValue);
}


function findNodeIdOverAttributeId(attributeID) { // Rückgabe der NodeID 
  let found;
  nodes.find((node) => node.attributes.find((attr) => attr.id === attributeID && (found = attr.node_id)));
  return found;
}

function findTypeOverAttributeId(attributeID) { // Rückgabe der Type Nummer 1 switch ....
  let found;
  nodes.find((node) => node.attributes.find((attr) => attr.id === attributeID && (found = attr.type)));
  return found;
}

function findNodeTypeOverAttributeId(attributeID) { // Rückgabe der Type Nummer 1 switch ....
  let found;
  nodes.find((node) => node.attributes.find((attr) => attr.id === attributeID && (found = node.profile)));
  return found;
}




function xytorgb(x,y,bri){
let  X, Y, z, Z, r, g, b;
let R, G, B, rgb;


  z = 1.0 - x - y;

  Y = bri / 255.0; // Brightness of lamp
  X = (Y / y) * x;
  Z = (Y / y) * z;
  r = X * 1.612 - Y * 0.203 - Z * 0.302;
  g = -X * 0.509 + Y * 1.412 + Z * 0.066;
  b = X * 0.026 - Y * 0.072 + Z * 0.962;

  r = r <= 0.0031308 ? 12.92 * r : (1.0 + 0.055) * Math.pow(r, (1.0 / 2.4)) - 0.055;
  g = g <= 0.0031308 ? 12.92 * g : (1.0 + 0.055) * Math.pow(g, (1.0 / 2.4)) - 0.055;
  b = b <= 0.0031308 ? 12.92 * b : (1.0 + 0.055) * Math.pow(b, (1.0 / 2.4)) - 0.055;

  if (r > b && r > g) {
    // red is biggest
    if (r > 1.0) {
      g = g / r;
      b = b / r;
      r = 1.0;
    }
  }
  else if (g > b && g > r) {
    // green is biggest
    if (g > 1.0) {
      r = r / g;
      b = b / g;
      g = 1.0;
    }
  }
  else if (b > r && b > g) {
    // blue is biggest
    if (b > 1.0) {
      r = r / b;
      g = g / b;
      b = 1.0;
    }
  }

  r = r * 255;
  if (r < 0) {
    r = 0;
  }

  g = g * 255;
  if (g < 0) {
    g = 0;
  }

  b = b * 255;
  if (b < 0) {
    b = 0;
  }

  R = Math.round(r);
  G = Math.round(g);
  B = Math.round(b);

  rgb = (16711680 / 255 * R) + (65280 / 255 * G) + B;
  
  return rgb;

}

let hue_x,hue_y;
 
function rgbtoxy(dec){
let Red, Green, Blue, XXY, YXY, ZXY, xXY, yXY, RXY, GXY, BXY, rXY, gXY, bXY;
let dec_i, Red_i, Green_i, Blue_i;

console.log(dec);

return dec1(dec);

function dec1(dec2) {
  dec_i = dec2;
  Blue_i = dec_i % 256;
  Green_i = ((dec_i - Blue_i) / 256) % 256;
  Red_i = ((dec_i - Blue_i) / 65536) - Green_i / 256;
  Blue = Blue_i;
  Red = Red_i;
  Green = Green_i;
console.log(Red);
console.log(Green);
console.log(Blue);

return  RGB2XY( Red,  Green,  Blue);
}
function RGB2XY(Red, Green, Blue) {
  Red = Red / 255.0;
  Green = Green / 255.0;
  Blue = Blue / 255.0;
  rXY = (Red   > 0.04045) ? Math.pow((Red   + 0.055) / (1 + 0.055), 2.4) : (Red   / 12.92);
  gXY = (Green > 0.04045) ? Math.pow((Green + 0.055) / (1 + 0.055), 2.4) : (Green / 12.92);
  bXY = (Blue  > 0.04045) ? Math.pow((Blue  + 0.055) / (1 + 0.055), 2.4) : (Blue  / 12.92);
  XXY = rXY * 0.649926 + gXY * 0.103455 + bXY * 0.197109;
  YXY = rXY * 0.234327 + gXY * 0.743075 + bXY * 0.022598;
  ZXY = rXY * 0.000000 + gXY * 0.053077 + bXY * 1.035763;
  xXY = XXY / (XXY + YXY + ZXY);
  yXY = YXY / (XXY + YXY + ZXY);
console.log(xXY);
console.log(yXY);
  return  {x : xXY, y : yXY};
}


}

