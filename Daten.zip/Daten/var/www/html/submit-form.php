<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Lese den JSON-String aus der Anfrage
  $json_str = file_get_contents('php://input');

  // Konvertiere den JSON-String in ein assoziatives Array
  $data = json_decode($json_str, true);

  // Schreibe das Array in die config.json-Datei
  $json = json_encode($data, JSON_PRETTY_PRINT);
  file_put_contents('config.json', $json);

  // Gib eine Bestätigung an den Client zurück
  echo "Die Daten wurden erfolgreich gespeichert!";
}
?>


