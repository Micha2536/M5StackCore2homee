
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['upload'])) {
    $uploadDir = '/home/pi/homeejs/';  // Pfad zum Zielverzeichnis außerhalb des Webverzeichnisses
    $uploadFile = $uploadDir . basename($_FILES['upload']['name']);
    
    $command = 'sudo mv ' . $_FILES['upload']['tmp_name'] . ' ' . $uploadFile;
    $commandChmod = 'sudo chmod 777 ' . $uploadFile;

    if (exec($command)) {
        echo 'Die Datei wurde erfolgreich hochgeladen und gespeichert.';
    } else {
        echo 'Fehler beim Hochladen der Datei.';
    }
}
?>


